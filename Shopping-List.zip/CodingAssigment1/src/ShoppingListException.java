/**
 * Erick Williams
 * CS111
 * Coding Assignment 1
 * 2/12/16
 */
public class ShoppingListException extends RuntimeException
{
	public ShoppingListException(String message)
	{
		super(message);
	}
}
